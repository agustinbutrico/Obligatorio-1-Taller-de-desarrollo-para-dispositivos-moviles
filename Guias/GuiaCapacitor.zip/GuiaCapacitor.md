1. Inicializar el Proyecto  
**Comando:**  
```bash
npm init
```  

Este comando inicializa un nuevo proyecto Node.js, creando un archivo `package.json` que será la base para gestionar las dependencias.

2. Instalar Capacitor Core  
**Comando:**  
```bash
npm install @capacitor/core
```  

Se instala el núcleo de Capacitor, que permite la integración de Ionic con las plataformas nativas (Android e iOS).

3. Instalar Capacitor CLI  
**Comando:**  
```bash
npm install @capacitor/cli --save-dev
```  

La herramienta CLI de Capacitor es necesaria para ejecutar comandos que configuran y sincronizan el proyecto con las plataformas nativas. Se instala como dependencia de desarrollo.

4. Inicializar Capacitor  
**Comando:**  
```bash
npx cap init
```  

Este comando configura Capacitor en el proyecto, solicitando un nombre para la aplicación y un identificador (por ejemplo, `com.ejemplo.app`).

5. Instalar el Soporte para Android  
**Comando:**  
```bash
npm install @capacitor/android
```  

Se instala el soporte de Capacitor para la plataforma Android, necesario para crear el APK.

6. Agregar la Plataforma Android  
**Comando:**  
```bash
npx cap add android
```  

Este comando agrega un proyecto nativo de Android al proyecto Capacitor. Esto crea una carpeta `android/` con el código necesario para trabajar con Android Studio.

7. Sincronizar el Proyecto  
**Comando:**  
```bash
npx cap sync
```  

Este comando sincroniza los archivos y configuraciones del proyecto Ionic con la carpeta de la plataforma Android.

8. Agregar Permisos en Android  
**Archivo:** `android/app/src/main/AndroidManifest.xml`  
Antes de compilar, es necesario agregar los permisos que la aplicación requiera. Por ejemplo:  
```xml
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-feature android:name="android.hardware.location.gps" />
```  

- `ACCESS_COARSE_LOCATION` y `ACCESS_FINE_LOCATION` permiten que la aplicación acceda a la ubicación del dispositivo.  
- `android.hardware.location.gps` indica que la aplicación utiliza la funcionalidad de GPS.  
Agrega estos permisos dentro del archivo `AndroidManifest.xml`, en la sección correspondiente.

9.  Generar el APK  
**Comando:**  
```bash
npx cap run android
```  



Una vez configurado todo, el archivo APK generado estará ubicado en:  
```bash
.../android/app/build/outputs/apk/debug/app-debug.apk
```  

Este es el APK de desarrollo (`debug`). Para generar un APK listo para producción, deberás firmarlo y compilarlo con la configuración de `release`.